<div class="admin-default-index">
    <h1>Панель администратора</h1>
</div>

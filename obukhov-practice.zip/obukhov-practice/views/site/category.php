<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                <article class="post post-list">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="post-thumb">
                                <a href="blog.html"><img src="/public/images/blog-grid.jpg" alt="" class="pull-left"></a>

                                <a href="blog.html" class="post-thumb-overlay text-center">
                                    <div class="text-uppercase text-center">Посмотреть</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="post-content">
                                <header class="entry-header text-uppercase">
                                    <h6><a href="#"> Travel</a></h6>

                                    <h1 class="entry-title"><a href="blog.html">Дом - это спокойное место</a></h1>
                                </header>
                                <div class="entry-content">
                                    <p>Lorem ipsum dolor sit amet, consadipsinesed diam nonumy eirmod tevidubore et
                                    </p>
                                </div>
                                <div class="social-share">
                                    <span class="social-share-title pull-left text-capitalize">Автор: Рубель 8 Ноября 2021 Года</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <article class="post post-list">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="post-thumb">
                                <a href="blog.html"><img src="/public/images/blog-grid.jpg" alt="" class="pull-left"></a>

                                <a href="blog.html" class="post-thumb-overlay text-center">
                                    <div class="text-uppercase text-center">Посмотреть</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="post-content">
                                <header class="entry-header text-uppercase">
                                    <h6><a href="#"> Travel</a></h6>

                                    <h1 class="entry-title"><a href="blog.html">Дом - это спокойное место</a></h1>
                                </header>
                                <div class="entry-content">
                                    <p>Lorem ipsum dolor sit amet, consadipsinesed diam nonumy eirmod tevidubore et
                                    </p>
                                </div>
                                <div class="social-share">
                                    <span class="social-share-title pull-left text-capitalize">Автор: Рубель 8 Ноября 2021 Года</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <article class="post post-list">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="post-thumb">
                                <a href="blog.html"><img src="/public/images/blog-grid.jpg" alt="" class="pull-left"></a>

                                <a href="blog.html" class="post-thumb-overlay text-center">
                                    <div class="text-uppercase text-center">Посмотреть</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="post-content">
                                <header class="entry-header text-uppercase">
                                    <h6><a href="#"> Travel</a></h6>

                                    <h1 class="entry-title"><a href="blog.html">Дом - это спокойное место</a></h1>
                                </header>
                                <div class="entry-content">
                                    <p>Lorem ipsum dolor sit amet, consadipsinesed diam nonumy eirmod tevidubore et
                                    </p>
                                </div>
                                <div class="social-share">
                                    <span class="social-share-title pull-left text-capitalize">Автор: Рубель 8 Ноября 2021 Года</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <article class="post post-list">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="post-thumb">
                                <a href="blog.html"><img src="/public/images/blog-grid.jpg" alt="" class="pull-left"></a>

                                <a href="blog.html" class="post-thumb-overlay text-center">
                                    <div class="text-uppercase text-center">Посмотреть</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="post-content">
                                <header class="entry-header text-uppercase">
                                    <h6><a href="#"> Travel</a></h6>

                                    <h1 class="entry-title"><a href="blog.html">Дом - это спокойное место</a></h1>
                                </header>
                                <div class="entry-content">
                                    <p>Lorem ipsum dolor sit amet, consadipsinesed diam nonumy eirmod tevidubore et
                                    </p>
                                </div>
                                <div class="social-share">
                                    <span class="social-share-title pull-left text-capitalize">Автор: Рубель 8 Ноября 2021 Года</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <ul class="pagination">
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                </ul>
            </div>
            <div class="col-md-4" data-sticky_column>
                <div class="primary-sidebar">

                    <aside class="widget">
                        <h3 class="widget-title text-uppercase text-center">Популярные посты</h3>

                        <div class="popular-post">


                            <a href="#" class="popular-img"><img src="/public/images/p1.jpg" alt="">

                                <div class="p-overlay"></div>
                            </a>

                            <div class="p-content">
                                <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                <span class="p-date">Ноябрь 8, 2021</span>

                            </div>
                        </div>
                        <div class="popular-post">

                            <a href="#" class="popular-img"><img src="/public/images/p1.jpg" alt="">

                                <div class="p-overlay"></div>
                            </a>

                            <div class="p-content">
                                <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                <span class="p-date">Ноябрь 8, 2021</span>
                            </div>
                        </div>
                        <div class="popular-post">


                            <a href="#" class="popular-img"><img src="/public/publicts/images/p1.jpg" alt="">

                                <div class="p-overlay"></div>
                            </a>

                            <div class="p-content">
                                <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                <span class="p-date">Ноябрь 8, 2021</span>
                            </div>
                        </div>
                    </aside>
                    <aside class="widget pos-padding">
                        <h3 class="widget-title text-uppercase text-center">Последние Сообщения</h3>

                        <div class="thumb-latest-posts">


                            <div class="media">
                                <div class="media-left">
                                    <a href="#" class="popular-img"><img src="/public/images/r-p.jpg" alt="">

                                        <div class="p-overlay"></div>
                                    </a>
                                </div>
                                <div class="p-content">
                                    <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                    <span class="p-date">Ноябрь 8, 2021</span>
                                </div>
                            </div>
                        </div>
                        <div class="thumb-latest-posts">


                            <div class="media">
                                <div class="media-left">
                                    <a href="#" class="popular-img"><img src="/public/images/r-p.jpg" alt="">

                                        <div class="p-overlay"></div>
                                    </a>
                                </div>
                                <div class="p-content">
                                    <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                    <span class="p-date">Ноябрь 8, 2021</span>
                                </div>
                            </div>
                        </div>
                        <div class="thumb-latest-posts">


                            <div class="media">
                                <div class="media-left">
                                    <a href="#" class="popular-img"><img src="/public/images/r-p.jpg" alt="">

                                        <div class="p-overlay"></div>
                                    </a>
                                </div>
                                <div class="p-content">
                                    <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                    <span class="p-date">Ноябрь 8, 2021</span>
                                </div>
                            </div>
                        </div>
                        <div class="thumb-latest-posts">


                            <div class="media">
                                <div class="media-left">
                                    <a href="#" class="popular-img"><img src="/public/images/r-p.jpg" alt="">

                                        <div class="p-overlay"></div>
                                    </a>
                                </div>
                                <div class="p-content">
                                    <a href="#" class="text-uppercase">Дом - это спокойное место</a>
                                    <span class="p-date">Ноябрь 8, 2021</span>
                                </div>
                            </div>
                        </div>
                    </aside>
                    <aside class="widget border pos-padding">
                        <h3 class="widget-title text-uppercase text-center">Категории</h3>
                        <ul>
                            <li>
                                <a href="#">Еда и Напитки</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                            <li>
                                <a href="#">Путешествия</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                            <li>
                                <a href="#">Бизнес</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                            <li>
                                <a href="#">История</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                            <li>
                                <a href="#">Поделки и советы</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                            <li>
                                <a href="#">Образ жизни</a>
                                <span class="post-count pull-right"> (2)</span>
                            </li>
                        </ul>
                    </aside>
                    <aside class="widget pos-padding">
                        <h3 class="widget-title text-uppercase text-center">Follow@Instagram</h3>

                        <div class="instragram-follow">
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>
                            <a href="#">
                                <img src="/public/images/ins-flow.jpg" alt="">
                            </a>

                        </div>

                    </aside>
                </div>
            </div>
        </div>
    </div>
</div>
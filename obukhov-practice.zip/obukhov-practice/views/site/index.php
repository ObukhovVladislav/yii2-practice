<?php

use yii\helpers\Url;
use yii\widgets\LinkPager;
?>

<div class="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php foreach ($articles as $article) : ?>
                    <article class="post">
                        <div class="post-thumb">
                            <a href="<?= Url::toRoute(['site/single', 'id' => $article->id]); ?>"><img src="<?= $article->getImage(); ?>" alt=""></a>

                            <a href="<?= Url::toRoute(['site/single', 'id' => $article->id]); ?>" class="post-thumb-overlay text-center">
                                <div class="text-uppercase text-center">Посмотреть</div>
                            </a>
                        </div>
                        <div class="post-content">
                            <header class="entry-header text-center text-uppercase">
                                <h6><a href="<?= Url::toRoute(['site/category', 'id' => $article->category->id]) ?>"><?= $article->category->title; ?></a></h6>
                                <h1 class="entry-title"><a href="<?= Url::toRoute(['site/single', 'id' => $article->id]); ?>"><?= $article->title; ?></a></h1>
                            </header>
                            <div class="entry-content">
                                <p> <?= $article->description; ?>
                                </p>
                                <div class="btn-continue-reading text-center text-uppercase">
                                    <a href="<?= Url::toRoute(['site/single', 'id' => $article->id]); ?>" class="more-link">Продолжить Чтение</a>
                                </div>
                            </div>
                            <div>
                                <span>Автор <a style="color:#070b4a;" href="#"><?= $article->author->name; ?></a> <?= $article->getDate(); ?></span>
                                <ul class="text-center pull-right">
                                    <li style="list-style-type: none;"><a href="#"><i class="viewed fa fa-eye" style="color:#070b4a;" aria-hidden="true"><?= (int) $article->viewed; ?></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>

                <?php
                echo LinkPager::widget([
                    'pagination' => $pagination,
                ]);
                ?>
            </div>
            <?= $this->render('/partials/sidebar', [
                'popular' => $popular,
                'recent' => $recent,
                'categories' => $categories
            ]); ?>
        </div>
    </div>
</div>